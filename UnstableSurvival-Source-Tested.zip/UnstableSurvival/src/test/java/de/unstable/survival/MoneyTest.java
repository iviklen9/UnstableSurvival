package de.unstable.survival;
import de.unstable.survival.economy.Money;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class MoneyTest {
 @Test void convertsDecimalToCents(){assertEquals(1234,Money.toCents("12.34"));}
 @Test void rejectsZeroAndNegative(){assertThrows(IllegalArgumentException.class,()->Money.toCents("0"));assertThrows(IllegalArgumentException.class,()->Money.toCents("-1"));}
 @Test void rejectsMoreThanTwoDecimalPlaces(){assertThrows(IllegalArgumentException.class,()->Money.toCents("1.001"));}
 @Test void formatsCents(){assertEquals("1000.05",Money.format(100005));}
}
