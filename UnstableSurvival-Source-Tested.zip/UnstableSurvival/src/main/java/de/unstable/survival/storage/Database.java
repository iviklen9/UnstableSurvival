package de.unstable.survival.storage;

import java.io.File;
import java.sql.*;
import java.util.UUID;
import java.util.concurrent.locks.ReentrantLock;

public final class Database implements AutoCloseable {
    private final Connection connection;
    private final ReentrantLock lock = new ReentrantLock();
    public Database(File file) throws SQLException {
        this.connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
        try (Statement s = connection.createStatement()) {
            s.execute("PRAGMA journal_mode=WAL");
            s.execute("PRAGMA foreign_keys=ON");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS accounts(uuid TEXT PRIMARY KEY, name TEXT NOT NULL, balance_cents INTEGER NOT NULL CHECK(balance_cents>=0))");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)");
        }
    }
    public void ensureAccount(UUID id, String name, long startingCents) throws SQLException {
        lock.lock(); try (PreparedStatement p=connection.prepareStatement("INSERT OR IGNORE INTO accounts(uuid,name,balance_cents) VALUES(?,?,?)")) {
            p.setString(1,id.toString()); p.setString(2,name); p.setLong(3,startingCents); p.executeUpdate();
        } finally { lock.unlock(); }
    }
    public long balance(UUID id) throws SQLException {
        lock.lock(); try (PreparedStatement p=connection.prepareStatement("SELECT balance_cents FROM accounts WHERE uuid=?")) {
            p.setString(1,id.toString()); try(ResultSet r=p.executeQuery()){return r.next()?r.getLong(1):0L;}
        } finally {lock.unlock();}
    }
    public boolean transfer(UUID from, UUID to, long cents) throws SQLException {
        if(cents<=0 || from.equals(to)) return false;
        lock.lock(); try {
            connection.setAutoCommit(false);
            try(PreparedStatement debit=connection.prepareStatement("UPDATE accounts SET balance_cents=balance_cents-? WHERE uuid=? AND balance_cents>=?");
                PreparedStatement credit=connection.prepareStatement("UPDATE accounts SET balance_cents=balance_cents+? WHERE uuid=?")) {
                debit.setLong(1,cents); debit.setString(2,from.toString()); debit.setLong(3,cents);
                if(debit.executeUpdate()!=1) {connection.rollback(); return false;}
                credit.setLong(1,cents); credit.setString(2,to.toString());
                if(credit.executeUpdate()!=1) {connection.rollback(); return false;}
                connection.commit(); return true;
            } catch(SQLException e){connection.rollback(); throw e;} finally {connection.setAutoCommit(true);}
        } finally {lock.unlock();}
    }
    public boolean withdraw(UUID id,long cents) throws SQLException {
        if(cents<=0)return false; lock.lock(); try(PreparedStatement p=connection.prepareStatement("UPDATE accounts SET balance_cents=balance_cents-? WHERE uuid=? AND balance_cents>=?")){
            p.setLong(1,cents);p.setString(2,id.toString());p.setLong(3,cents);return p.executeUpdate()==1;
        }finally{lock.unlock();}
    }
    public void deposit(UUID id,long cents) throws SQLException {
        if(cents<=0)throw new IllegalArgumentException("cents must be positive"); lock.lock();try(PreparedStatement p=connection.prepareStatement("UPDATE accounts SET balance_cents=balance_cents+? WHERE uuid=?")){
            p.setLong(1,cents);p.setString(2,id.toString());if(p.executeUpdate()!=1)throw new SQLException("Account does not exist");
        }finally{lock.unlock();}
    }
    public ResultSet topTen() throws SQLException { lock.lock(); try { Statement s=connection.createStatement(); return s.executeQuery("SELECT name,balance_cents FROM accounts ORDER BY balance_cents DESC LIMIT 10"); } finally {lock.unlock();} }
    public void saveSetting(String key,String value)throws SQLException{lock.lock();try(PreparedStatement p=connection.prepareStatement("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value")){p.setString(1,key);p.setString(2,value);p.executeUpdate();}finally{lock.unlock();}}
    public String setting(String key)throws SQLException{lock.lock();try(PreparedStatement p=connection.prepareStatement("SELECT value FROM settings WHERE key=?")){p.setString(1,key);try(ResultSet r=p.executeQuery()){return r.next()?r.getString(1):null;}}finally{lock.unlock();}}
    @Override public void close() throws SQLException { lock.lock();try{connection.close();}finally{lock.unlock();} }
}
