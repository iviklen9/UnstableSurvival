package de.unstable.survival.economy;
import java.math.BigDecimal;
import java.math.RoundingMode;
public final class Money {
 private Money(){}
 public static long toCents(String raw){
  try {
   BigDecimal v=new BigDecimal(raw).setScale(2,RoundingMode.UNNECESSARY);
   if(v.signum()<=0)throw new IllegalArgumentException("Amount must be positive");
   return v.movePointRight(2).longValueExact();
  } catch (NumberFormatException | ArithmeticException ex) {
   throw new IllegalArgumentException("Amount must be a positive number with at most two decimal places", ex);
  }
 }
 public static String format(long cents){return BigDecimal.valueOf(cents,2).setScale(2).toPlainString();}
}
