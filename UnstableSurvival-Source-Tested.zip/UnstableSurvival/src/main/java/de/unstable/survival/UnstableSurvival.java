package de.unstable.survival;

import de.unstable.survival.storage.Database;
import de.unstable.survival.economy.Money;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import java.sql.*;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public final class UnstableSurvival extends JavaPlugin implements Listener, TabCompleter {
    private Database database;
    private FileConfiguration shopConfig;
    private NamespacedKey guiKey, customIdKey;
    private final Set<UUID> busy = new HashSet<>();
    private final Map<UUID,Long> rtpCooldown = new HashMap<>();
    private Inventory shop;

    @Override public void onEnable() {
        saveDefaultConfig(); saveResource("messages.yml",false); saveResource("shop.yml",false); saveResource("recipes.yml",false);
        shopConfig = YamlConfiguration.loadConfiguration(new java.io.File(getDataFolder(), "shop.yml"));
        try { database = new Database(new java.io.File(getDataFolder(),"data.db")); }
        catch(SQLException e){getLogger().severe("SQLite konnte nicht geöffnet werden: "+e.getMessage()); getServer().getPluginManager().disablePlugin(this); return;}
        guiKey=new NamespacedKey(this,"gui"); customIdKey=new NamespacedKey(this,"custom_item_id");
        for(String name:List.of("bal","pay","baltop","spawn","setspawn","rtp","shop")) {
            PluginCommand command=getCommand(name);
            if(command==null){getLogger().severe("Command fehlt in plugin.yml: /"+name);getServer().getPluginManager().disablePlugin(this);return;}
            command.setExecutor(this::execute); command.setTabCompleter(this);
        }
        getServer().getPluginManager().registerEvents(this,this);
        for(Player p:Bukkit.getOnlinePlayers()) ensureAccount(p);
        getLogger().info("UnstableSurvival 1.0.0 aktiviert.");
    }
    @Override public void onDisable(){ if(database!=null)try{database.close();}catch(SQLException e){getLogger().severe("SQLite-Schließen fehlgeschlagen: "+e.getMessage());} busy.clear(); }
    @EventHandler public void onJoin(org.bukkit.event.player.PlayerJoinEvent e){ensureAccount(e.getPlayer());}
    private void ensureAccount(Player p){try{database.ensureAccount(p.getUniqueId(),p.getName(),Math.round(getConfig().getDouble("economy.starting-balance",1000)*100));}catch(SQLException e){getLogger().severe("Account konnte nicht initialisiert werden: "+e.getMessage());}}
    private boolean execute(CommandSender sender,Command cmd,String label,String[] args){
        String c=cmd.getName().toLowerCase(Locale.ROOT);
        try {
            switch(c){
                case "bal" -> {if(args.length>1)return usage(sender,"/bal [Spieler]"); if(args.length==1){OfflinePlayer target=Bukkit.getOfflinePlayer(args[0]); if(!target.hasPlayedBefore()&&!target.isOnline()){sender.sendMessage("§cSpielerkonto nicht gefunden.");return true;} sender.sendMessage("§bGuthaben von "+target.getName()+": §f$"+Money.format(database.balance(target.getUniqueId())));}else if(sender instanceof Player p)sender.sendMessage("§bGuthaben: §f$"+Money.format(database.balance(p.getUniqueId())));else sender.sendMessage("§cKonsole muss einen Spieler angeben.");}
                case "pay" -> {if(!(sender instanceof Player p))return playerOnly(sender);if(args.length!=2)return usage(sender,"/pay <Spieler> <Betrag>");OfflinePlayer t=Bukkit.getOfflinePlayer(args[0]);if(t.getUniqueId().equals(p.getUniqueId())){p.sendMessage("§cDu kannst dir selbst kein Geld senden.");return true;}long amount=Money.toCents(args[1]);if(!t.hasPlayedBefore()&&!t.isOnline()){p.sendMessage("§cSpielerkonto nicht gefunden.");return true;}ensureOfflineAccount(t);if(database.transfer(p.getUniqueId(),t.getUniqueId(),amount))p.sendMessage("§aÜberwiesen: $"+Money.format(amount));else p.sendMessage("§cÜberweisung fehlgeschlagen: Guthaben prüfen.");}
                case "baltop" -> {sender.sendMessage("§b§lTop 10 Guthaben:");try(ResultSet r=database.topTen()){int i=1;while(r.next())sender.sendMessage("§7"+i+++". §f"+r.getString(1)+" §8- §a$"+Money.format(r.getLong(2)));}}
                case "setspawn" -> {if(!(sender instanceof Player p))return playerOnly(sender);if(!sender.hasPermission("unstablesurvival.setspawn"))return noPerm(sender);Location l=p.getLocation();database.saveSetting("spawn.world",l.getWorld().getName());database.saveSetting("spawn.x",Double.toString(l.getX()));database.saveSetting("spawn.y",Double.toString(l.getY()));database.saveSetting("spawn.z",Double.toString(l.getZ()));database.saveSetting("spawn.yaw",Float.toString(l.getYaw()));database.saveSetting("spawn.pitch",Float.toString(l.getPitch()));p.sendMessage("§aSpawn gespeichert.");}
                case "spawn" -> {if(!(sender instanceof Player p))return playerOnly(sender);String w=database.setting("spawn.world");if(w==null){p.sendMessage("§cSpawn wurde noch nicht gesetzt.");return true;}World world=Bukkit.getWorld(w);if(world==null){p.sendMessage("§cDie Spawn-Welt ist nicht geladen.");return true;}Location l=new Location(world,Double.parseDouble(database.setting("spawn.x")),Double.parseDouble(database.setting("spawn.y")),Double.parseDouble(database.setting("spawn.z")),Float.parseFloat(database.setting("spawn.yaw")),Float.parseFloat(database.setting("spawn.pitch")));p.teleport(l);p.sendMessage("§aZum Spawn teleportiert.");}
                case "rtp" -> {if(!(sender instanceof Player p))return playerOnly(sender);long now=System.currentTimeMillis(),next=rtpCooldown.getOrDefault(p.getUniqueId(),0L);if(now<next){p.sendMessage("§cBitte warte noch "+((next-now+999)/1000)+" Sekunden.");return true;}World world=Bukkit.getWorld(getConfig().getString("rtp.world","world"));if(world==null){p.sendMessage("§cRTP-Welt nicht gefunden.");return true;}int min=getConfig().getInt("rtp.min-radius",500),max=getConfig().getInt("rtp.max-radius",5000),tries=getConfig().getInt("rtp.max-attempts",40);for(int i=0;i<tries;i++){double a=ThreadLocalRandom.current().nextDouble(0,Math.PI*2),r=ThreadLocalRandom.current().nextDouble(min,max);int x=(int)(Math.cos(a)*r),z=(int)(Math.sin(a)*r);if(Math.abs(x)>=world.getWorldBorder().getSize()/2||Math.abs(z)>=world.getWorldBorder().getSize()/2)continue;int y=world.getHighestBlockYAt(x,z);Material floor=world.getBlockAt(x,y-1,z).getType();if(!floor.isSolid()||floor==Material.MAGMA_BLOCK||floor==Material.CAMPFIRE||floor==Material.SOUL_CAMPFIRE||world.getBlockAt(x,y,z).getType()!=Material.AIR||world.getBlockAt(x,y+1,z).getType()!=Material.AIR)continue;p.teleport(new Location(world,x+0.5,y,z+0.5));rtpCooldown.put(p.getUniqueId(),now+getConfig().getLong("rtp.cooldown-seconds",60)*1000);p.sendMessage("§aZufällig teleportiert.");return true;}p.sendMessage("§cKeine sichere Position gefunden. Versuche es erneut.");}
                case "shop" -> {if(!(sender instanceof Player p))return playerOnly(sender);openShop(p);}
            }
        }catch(IllegalArgumentException e){sender.sendMessage("§cUngültiger Betrag oder Parameter.");}catch(SQLException e){getLogger().severe("Datenbankfehler bei /"+c+": "+e.getMessage());sender.sendMessage("§cDatenbankfehler. Bitte Admin informieren.");}
        return true;
    }
    private void ensureOfflineAccount(OfflinePlayer p)throws SQLException{database.ensureAccount(p.getUniqueId(),p.getName()==null?"Unknown":p.getName(),Math.round(getConfig().getDouble("economy.starting-balance",1000)*100));}
    private boolean usage(CommandSender s,String m){s.sendMessage("§cVerwendung: "+m);return true;} private boolean playerOnly(CommandSender s){s.sendMessage("§cNur Spieler können diesen Befehl verwenden.");return true;}private boolean noPerm(CommandSender s){s.sendMessage("§cKeine Berechtigung.");return true;}
    private void openShop(Player p){shop=Bukkit.createInventory(null,27,"§8Unstable Shop");ConfigurationSection items=shopConfig.getConfigurationSection("items");if(items!=null)for(String key:items.getKeys(false)){ConfigurationSection sec=items.getConfigurationSection(key);if(sec==null)continue;Material m=Material.matchMaterial(sec.getString("material","STONE"));if(m==null)continue;ItemStack it=new ItemStack(m,Math.max(1,sec.getInt("amount",1)));ItemMeta meta=it.getItemMeta();meta.setDisplayName("§bKaufen: §f"+key);meta.setLore(List.of("§7Preis: §a$"+String.format(Locale.US,"%.2f",sec.getDouble("price")),"§eKlicke zum Kaufen"));meta.getPersistentDataContainer().set(guiKey,PersistentDataType.STRING,key);it.setItemMeta(meta);int slot=sec.getInt("slot",shop.firstEmpty());if(slot>=0&&slot<shop.getSize())shop.setItem(slot,it);}p.openInventory(shop);}
    @EventHandler public void onInventoryClick(InventoryClickEvent e){if(!(e.getWhoClicked() instanceof Player p))return;if(e.getView().getTitle().equals("§8Unstable Shop")){e.setCancelled(true);if(e.getClickedInventory()==null||e.getClickedInventory()!=e.getView().getTopInventory())return;ItemStack clicked=e.getCurrentItem();if(clicked==null||!clicked.hasItemMeta())return;String id=clicked.getItemMeta().getPersistentDataContainer().get(guiKey,PersistentDataType.STRING);if(id==null||busy.contains(p.getUniqueId()))return;ConfigurationSection sec=shopConfig.getConfigurationSection("items."+id);if(sec==null)return;long price=Math.round(sec.getDouble("price")*100);busy.add(p.getUniqueId());try{if(database.withdraw(p.getUniqueId(),price)){Material buyMaterial=Material.matchMaterial(sec.getString("material","STONE"));if(buyMaterial==null||sec.getInt("amount",1)<1){p.sendMessage("§cDieses Shop-Item ist falsch konfiguriert.");return;}ItemStack bought=new ItemStack(buyMaterial,sec.getInt("amount",1));Map<Integer,ItemStack> overflow=p.getInventory().addItem(bought);overflow.values().forEach(item->p.getWorld().dropItemNaturally(p.getLocation(),item));p.sendMessage("§aGekauft für $"+Money.format(price));}else p.sendMessage("§cNicht genug Geld.");}catch(SQLException ex){getLogger().severe("Shop-Transaktion fehlgeschlagen: "+ex.getMessage());p.sendMessage("§cKauf fehlgeschlagen.");}finally{busy.remove(p.getUniqueId());}}}
    @Override public List<String> onTabComplete(CommandSender s,Command c,String a,String[] args){if(c.getName().equalsIgnoreCase("bal")&&args.length==1||c.getName().equalsIgnoreCase("pay")&&args.length==1)return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(n->n.toLowerCase(Locale.ROOT).startsWith(args[0].toLowerCase(Locale.ROOT))).toList();return List.of();}
}
