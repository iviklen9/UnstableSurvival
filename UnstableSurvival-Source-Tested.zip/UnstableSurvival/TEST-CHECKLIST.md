# Abnahme- und Testcheckliste

Status: noch nicht ausgeführt. Ein Haken darf erst nach tatsächlicher Prüfung gesetzt werden.

## Build / Laufzeit
- [ ] `mvn clean verify` erfolgreich
- [ ] Plugin startet auf Paper 1.21.11 mit Java 21
- [ ] Plugin deaktiviert ohne Fehler
- [ ] Alle in `plugin.yml` deklarierten Commands besitzen Executor und TabCompleter

## Persistenz / Economy
- [ ] Startguthaben wird genau einmal vergeben
- [ ] Guthaben bleibt nach Neustart erhalten
- [ ] Pay: gültige Überweisung
- [ ] Pay: Selbstüberweisung, negative Beträge und unzureichendes Guthaben werden abgelehnt
- [ ] Baltop listet die zehn höchsten Konten

## Spawn / RTP / GUI
- [ ] Spawn bleibt nach Neustart erhalten
- [ ] RTP liefert nur sichere getestete Oberflächenpositionen
- [ ] RTP-Cooldown greift
- [ ] Shop-GUI verhindert Verschieben und Entnehmen
- [ ] Shop-Kauf bei ausreichendem und unzureichendem Guthaben testen
- [ ] Shop-Kauf bei vollem Inventar testen

## Noch nicht implementierte Spezifikationspunkte
- [ ] Auction House und doppelte Kaufverhinderung
- [ ] Orders einschließlich Teilverkäufen und Reservierungsrückzahlung
- [ ] Custom-Item-IDs und Fähigkeiten
- [ ] Crafting-Rezepte
- [ ] Vollständige atomare Geld-/Item-Transaktionen mit Transaktions-IDs und Recovery
