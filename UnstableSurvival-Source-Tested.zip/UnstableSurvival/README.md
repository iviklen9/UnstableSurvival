# UnstableSurvival 1.0.0 – Entwicklungsstand

Paper-Plugin-Grundprojekt für Java 21 und Paper 1.21.11. Die Implementierung ist bewusst ehrlich als **Teilimplementierung** gekennzeichnet; sie erfüllt noch nicht die komplette Spezifikation.

## Enthaltene Funktionen

- SQLite-Datenbank mit UUID-Konten und WAL-Modus
- Startguthaben und persistente Kontostände
- `/bal [Spieler]`, `/pay <Spieler> <Betrag>`, `/baltop`
- `/setspawn` und `/spawn` mit Speicherung der Welt und Blickrichtung
- `/rtp` mit konfigurierbarem Radius, Versuchen und Cooldown; Kandidatenprüfung erfolgt synchron auf dem Serverthread
- Einfaches konfigurierbares Shop-GUI mit Kaufabbuchung
- Tab-Completion für Spielernamen bei `/bal` und `/pay`
- GitHub Actions Workflow und grundlegende Money-Unit-Tests

## Noch nicht implementiert

Die folgenden Punkte aus der Spezifikation sind **nicht** fertig und dürfen nicht als funktionsfähig angesehen werden: vollständiges Orbital-Custom-Item-System und Fähigkeiten, Crafting-Rezepte, Auction House (`/ah`), Orders (`/orders`), `/withdraw`, Shop-Verkauf/Kategorien/Seiten, Spawn-Teleportverzögerung, vollständige Transaktionsjournale/IDs und Rollback über Items und Geld hinweg, Offline-Name-Auflösung und umfassende Integrationstests.

Die Shop-Auslieferung von Items und Geldabbuchung ist nicht crash-atomar. RTP prüft grundlegende Oberflächenbedingungen, ist aber kein vollständiger Schutz gegen jede denkbare gefährliche Umgebung. Das Plugin wurde hier nicht auf einem echten Paper-Server gestartet.

## Voraussetzungen

- Java 21
- Paper 1.21.11
- Maven 3.9+

## Build

```bash
mvn clean verify
```

Die finale JAR wird durch Maven Shade unter `target/UnstableSurvival.jar` erzeugt. Der GitHub-Actions-Workflow führt denselben Verify-Build aus und lädt das Artefakt nur bei Erfolg hoch.

## Installation

1. `UnstableSurvival.jar` in den `plugins`-Ordner des Paper-Servers kopieren.
2. Server starten.
3. Werte in `plugins/UnstableSurvival/config.yml` anpassen.
4. Server neu starten.

## Commands und Permissions

| Command | Permission | Zweck |
|---|---|---|
| `/bal [Spieler]` | `unstablesurvival.economy` | Kontostand anzeigen |
| `/pay <Spieler> <Betrag>` | `unstablesurvival.economy` | Geld überweisen |
| `/baltop` | `unstablesurvival.economy` | Top 10 anzeigen |
| `/spawn` | `unstablesurvival.spawn` | Zum gespeicherten Spawn |
| `/setspawn` | `unstablesurvival.setspawn` | Spawn setzen |
| `/rtp` | `unstablesurvival.rtp` | Zufälliger Oberflächen-Teleport |
| `/shop` | `unstablesurvival.shop` | Shop öffnen |

`unstablesurvival.admin` ist als Admin-Permission deklariert, wird in dieser Teilversion aber nicht für zusätzliche Admin-Tools verwendet. LuckPerms ist nicht erforderlich; Bukkit-Permissions sind kompatibel.

## Qualitätsstatus

- Maven-Build: **nicht ausgeführt** (in der Erstellungsumgebung ist Maven nicht installiert).
- Automatisierte Tests: **vorhanden, aber nicht ausgeführt**.
- Echter Paper-1.21.11-Servertest: **nicht durchgeführt**.

Vor produktivem Einsatz muss der Build in GitHub Actions oder lokal mit Maven erfolgreich ausgeführt werden. Danach sind die offenen Module und Integrationsprüfungen umzusetzen.
